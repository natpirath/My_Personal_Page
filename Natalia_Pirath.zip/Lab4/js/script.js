/*creating variable*/
let emailInput = document.getElementById("email");
let termsInput = document.getElementById("terms");
let passInput = document.getElementById("pass");
let passInput2 = document.getElementById("pass2");
let emailError = document.getElementById("emailError")
let termsError = document.getElementById("termsError")
let passError = document.getElementById("passError")
let passError2 = document.getElementById("passError2")

/*Inserting an empty string to the defaultMsg variable*/
let defaultMsg = "";

/*Validating if the e-mail inputted by the user is in the right format.
 *Otherwise outputing an error.
 */
function validateEmail() {
    let email = emailInput.value;
    let emailErrorMsg = "Please enter a valid email to continue";
    let regexp = /\S+@\S+\.\S/; //Taken from https://stackoverflow.com/a/9204568
    let error = regexp.test(email) ? "" : emailErrorMsg;
    return error;
}

/*Validating if the terms and conditions checkbox is checked.
 *Otherwise outputing an error.
 */
function validateTerms() {
    let termsErrorMsg = "Please agree to the terms and conditions to continue";
    let error = termsInput.checked ? defaultMsg : termsErrorMsg;
    return error;
}

/*Validating if the password is not empty
 *Otherwise outputing an error.
 */
function validatePass() {
    let password = passInput.value;
    let noPassErrorMsg = "Please enter a valid Password";
    if (password.length == 0) {
        return noPassErrorMsg;
    }
}

/*Validating if the password and the re-Type password have the same value
 *Otherwise outputing an error.
 */
function validatePass2() {
    let password = passInput.value
    let password2 = passInput2.value;
    let noMatchErrorMsg = "Passwords don't match";

    if (password !== password2) {
        return noMatchErrorMsg;
    }
}

/*Resetinf the error messages if the form is reset*/
function resetFormError() {
    emailError.textContent = '';
    termsError.textContent = '';
    passError.textContent = '';
    passError2.textContent = '';
}

/*Validate if the form containg no error, if true it will direct to a link.
 *If false it will stay in the form page.
 */
function validate() {
    let valid = true;
    let emailValidation = validateEmail();
    let termsValidation = validateTerms();
    let passValidation = validatePass();
    let passValidation2 = validatePass2();

    if (emailValidation !== "") {
        emailError.textContent = emailValidation;
        valid = false;
    }
    if (termsValidation !== "") {
        termsError.textContent = termsValidation;
        valid = false;
    }
    if (passValidation !== "") {
        passError.textContent = passValidation;
    }
    if (passValidation2 !== "") {
        passError2.textContent = passValidation2;
    }
    return valid;

}

/*This will clear the error messages when the error issue is resolved*/
emailInput.addEventListener("blur", function() {
    if (validateEmail() == "") {
        emailError.textContent = "";
    }
})

/*This will clear the error messages when the error issue is resolved*/
termsInput.addEventListener("change", function() {
    if (this.checked) {
        termsError.textContent = "";
    }
})

/*This will clear the error messages when the error issue is resolved*/
passInput.addEventListener("blur", function() {
    if (validatePass() == "") {
        passError.textContent = "";
    }
})

/*This will clear the error messages when the error issue is resolved*/
passInput2.addEventListener("blur", function() {
    if (validatePass2() == "") {
        passError2.textContent = "";
    }
})

/*This will add a reset event listener to the form to invoke the resetProfile() method when the form is reset*/
document.form.addEventListener("reset", resetFormError);
